CKSN NEET CBT Website
Open index.html in a browser. For public hosting, upload this file/folder to a static hosting service.
This is a starter/demo question bank; replace/add questions before public educational use.
